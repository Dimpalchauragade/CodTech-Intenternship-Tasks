chrome.storage.local.get(null, (data) => {

    const list = document.getElementById("list");

    // 🔥 clear old list
    list.innerHTML = "";

    let productiveTime = 0;
    let unproductiveTime = 0;
    let otherTime = 0;

    for (let site in data) {

        // ❗ skip non-website data (IMPORTANT FIX)
        if (typeof data[site] !== "number") continue;

        let time = data[site];
        let minutes = (time / 60000).toFixed(1);

        // show website time
        const li = document.createElement("li");
        li.textContent = `${site} : ${minutes} min`;
        list.appendChild(li);

        // classify
        if (
            site.includes("github") ||
            site.includes("stackoverflow") ||
            site.includes("chatgpt") ||
            site.includes("superset") ||
            site.includes("docs") ||
            site.includes("learn") ||
            site.includes("course")
        ) {
            productiveTime += time;
        }
        else if (
            site.includes("youtube") ||
            site.includes("instagram") ||
            site.includes("facebook") ||
            site.includes("netflix") ||
            site.includes("reel")
        ) {
            unproductiveTime += time;
        }
        else {
            otherTime += time;
        }
    }

    // 🔥 Weekly Report
    let total = productiveTime + unproductiveTime;

    const report = document.createElement("div");

    report.innerHTML = `
        <hr>
        <h4>📊 Weekly Report</h4>
        <p style="color:green;">Productive: ${(productiveTime/60000).toFixed(1)} min</p>
        <p style="color:red;">Unproductive: ${(unproductiveTime/60000).toFixed(1)} min</p>
        <p><b>Total: ${(total/60000).toFixed(1)} min</b></p>
        <p style="color:orange;">Other: ${(otherTime/60000).toFixed(1)} min</p>
    `;

    // ✅ safe score calculation
    let score = total > 0 ? (productiveTime / total) * 100 : 0;

    report.innerHTML += `<p><b>Score: ${score.toFixed(1)}%</b></p>`;

    list.appendChild(report);

    // ✅ progress bar update
    const progress = document.getElementById("progress");
    if (progress) {
        progress.style.width = score + "%";
    }
});


// 🔥 Start / Stop Tracking Button
document.getElementById("toggleTracking").addEventListener("click", () => {

    chrome.storage.local.get("tracking", (res) => {

        let tracking = res.tracking !== false; // default true

        tracking = !tracking;

        chrome.storage.local.set({ tracking });

        document.getElementById("toggleTracking").innerText =
            tracking ? "Stop Tracking" : "Start Tracking";
    });
});