let startTime = Date.now();
let currentSite = "";

chrome.tabs.onActivated.addListener(async (activeInfo) => {

    chrome.storage.local.get("tracking", async (res) => {

        if (res.tracking === false) {
            console.log("Tracking stopped ❌");
            return;
        }

        console.log("Tracking running ✅");

        const tab = await chrome.tabs.get(activeInfo.tabId);

        if (!tab.url || tab.url.startsWith("chrome://")) return;

        const url = new URL(tab.url);
        const site = url.hostname;

        // save previous site time
        if (currentSite) {
            let timeSpent = Date.now() - startTime;

            chrome.storage.local.get([currentSite], (result) => {
                let total = result[currentSite] || 0;
                total += timeSpent;

                chrome.storage.local.set({ [currentSite]: total });
            });
        }

        currentSite = site;
        startTime = Date.now();

    });
});